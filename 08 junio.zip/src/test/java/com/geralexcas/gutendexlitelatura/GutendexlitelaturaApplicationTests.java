package com.geralexcas.gutendexlitelatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GutendexlitelaturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
