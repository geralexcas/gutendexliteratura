package com.geralexcas.gutendexlitelatura.model;

public class Libro {

    private String titulo;
    private   String idiomas;
    private Autor autores;


}
