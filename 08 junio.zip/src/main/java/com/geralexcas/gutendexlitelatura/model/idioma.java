package com.geralexcas.gutendexlitelatura.model;

public class idioma {
}
