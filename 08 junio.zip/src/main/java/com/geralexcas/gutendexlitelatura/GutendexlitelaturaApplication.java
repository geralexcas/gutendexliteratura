package com.geralexcas.gutendexlitelatura;

import com.geralexcas.gutendexlitelatura.model.Datos;
import com.geralexcas.gutendexlitelatura.model.DatosLibros;
import com.geralexcas.gutendexlitelatura.model.Libro;
import com.geralexcas.gutendexlitelatura.service.ConvierteDatos;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.geralexcas.gutendexlitelatura.service.ConsumoApi;

import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@SpringBootApplication
public class GutendexlitelaturaApplication  implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(GutendexlitelaturaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		var consumoApi = new ConsumoApi();
		var json = consumoApi.obtenerDatos("https://gutendex.com/books/?search=%20romeo%20and%20juliet");
		//System.out.println(json);
		ConvierteDatos conversor = new ConvierteDatos();
		var datosBusqueda = conversor.obtenerDatos(json, Datos.class);
		System.out.println(datosBusqueda);
		Optional<DatosLibros> libroBuscado = datosBusqueda.resultados().stream()
				.findFirst();
		if (libroBuscado.isPresent()) {
			System.out.println(
					"\n------------- LIBRO --------------" +
							"\nTítulo: " + libroBuscado.get().titulo() +
							"\nAutor: " + libroBuscado.get().autores().stream()
							.map(a->a.nombre()).limit(1).collect(Collectors.joining())+
									"\nIdioma: " +libroBuscado.get().idiomas().stream()
									.collect(Collectors.joining())+


							"\n--------------------------------------\n"
			);


		}
	}
}
